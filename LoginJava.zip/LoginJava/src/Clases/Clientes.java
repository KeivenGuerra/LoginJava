package Clases;

import java.sql.*;

public class Clientes {
   
    private String nombre;
    private String apellido;
    private String direccion;
    private String telefono;
   

    // Método para listar todos los clientes
    public ResultSet listarCliente() {
        Conector db = new Conector();
        ResultSet rs = null;
        try {
            db.conectar();
            String query = "SELECT * FROM clientes";
            rs = db.executeSelect(query);
        } catch (SQLException e) {
            System.err.println("Error al listar los clientes: " + e.getMessage());
        }
        return rs;
    }
   
    // Método para insertar un nuevo cliente
    public int guardarCliente(String nombre, String apellido, String direccion, String telefono) throws SQLException {
        Conector db = new Conector();
        try {
            db.conectar();
            String query = "INSERT INTO clientes (nombre, apellido, direccion, telefono, cargo, genero) VALUES (?, ?, ?, ?, ?, ?)";
            return db.executeUpdate(query, nombre, apellido, direccion, telefono);
        } finally {
            db.desconectar();
        }
    }

    // Método para actualizar un cliente existente
    public int actualizarCliente(int id, String nombre, String apellido, String direccion, String telefono) throws SQLException {
        Conector db = new Conector();
        try {
            db.conectar();
            String query = "UPDATE clientes SET nombre = ?, apellido = ?, direccion = ?, telefono = ?, cargo = ?, genero = ? WHERE id = ?";
            return db.executeUpdate(query, nombre, apellido, direccion, telefono, id);
        } finally {
            db.desconectar();
        }
    }

    // Método para eliminar un cliente
    public int eliminarCliente(int id) throws SQLException {
        Conector db = new Conector();
        try {
            db.conectar();
            String query = "DELETE FROM clientes WHERE id = ?";
            return db.executeUpdate(query, id);
        } finally {
            db.desconectar();
        }
    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

   